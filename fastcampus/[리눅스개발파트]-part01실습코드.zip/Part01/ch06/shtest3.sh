#!/bin/sh
first=$1
second=$2
echo “1- $1”
echo “2- $2”

