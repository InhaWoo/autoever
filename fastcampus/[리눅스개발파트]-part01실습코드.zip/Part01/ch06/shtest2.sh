#!/bin/sh
echo "This is shtest2"
echo $shvar
