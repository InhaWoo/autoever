#!/bin/sh
shvar="Hello World"
export shvar
echo "Call shtest2"
./shtest2.sh
echo "Done"
