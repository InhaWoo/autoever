#!/bin/sh
if [ "$1" = "fork" ]
then
    echo "fork not allowed."
    exit
elif [ "$1" = "knife" ]
then
    echo "knife not allowed."
    exit
else
    echo "fork & knife not allowed"
    fi 
echo "spoon please"

