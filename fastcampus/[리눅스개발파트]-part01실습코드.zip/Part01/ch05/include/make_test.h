#ifndef __MAKE_TEST_H__
#define __MAKE_TEST_H__

#define MAX_NUM 5

#endif
